OOO SQUARE CRAWL — ANDROID PROJECT (v0.82)

What this is
------------
This project packages the supplied Ooo Square Crawl HTML file as a local Android
application. The game is loaded from the app's bundled assets using Android
WebViewAssetLoader, so the game itself does not need a website or game server.
JavaScript and DOM storage are enabled. No INTERNET permission is declared.

Important notes
---------------
1. The current HTML references Google Fonts. Without internet those fonts will
   not download; the page should use its configured fallback fonts. All game
   logic remains local.
2. The app currently enables browser local storage. Before relying on it for a
   long campaign, the save/load, export/import, and app-update behavior must be
   tested on a real Android device.
3. This is an initial Android wrapper, not a verified final APK. A full
   device-level gameplay and save-persistence test has not yet been performed.
4. The build requires Android Studio (or Android SDK + Gradle) and an internet
   connection once to download Android build dependencies. Gameplay itself
   does not require internet.

Build with Android Studio
-------------------------
1. Install Android Studio on a computer.
2. Open this folder as an existing project.
3. Allow Gradle to sync and download the Android Gradle Plugin and AndroidX
   WebKit dependency.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio creates:
   app/build/outputs/apk/debug/app-debug.apk
6. Transfer that APK to your Android phone and install it. You may need to
   allow installation from that file manager.

Optional build without setting up Android Studio locally
---------------------------------------------------------
The included GitHub Actions workflow can build a debug APK in GitHub's hosted
runner. Put this project in a GitHub repository, then run:
Actions > Build Ooo Square Crawl APK > Run workflow.
Download the APK from the workflow run's Artifacts section. This uses the
internet only for building/downloading the APK; the installed game runs locally.

Project details
---------------
Application ID: com.ooosquarecrawl
Version: 0.82
Minimum Android version: Android 6.0 (API 23)
Target SDK: 35
